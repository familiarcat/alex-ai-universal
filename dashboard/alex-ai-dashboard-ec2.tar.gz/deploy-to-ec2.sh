#!/bin/bash
# Deploy Alex AI Dashboard to EC2

echo "🚀 Deploying Alex AI Dashboard to EC2..."

# Install PM2 if not installed
if ! command -v pm2 &> /dev/null; then
    echo "📦 Installing PM2..."
    npm install -g pm2
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Stop existing dashboard if running
pm2 stop alex-ai-dashboard 2>/dev/null || echo "No existing dashboard to stop"

# Start the dashboard
echo "🚀 Starting Alex AI Dashboard..."
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Set up PM2 to start on boot
pm2 startup

echo "✅ Alex AI Dashboard deployed successfully!"
echo "📊 Dashboard running on port 3001"
echo "🔗 Access: http://n8n.pbradygeorgen.com:3001"
echo "📋 PM2 Status: pm2 status"
echo "📋 PM2 Logs: pm2 logs alex-ai-dashboard"
