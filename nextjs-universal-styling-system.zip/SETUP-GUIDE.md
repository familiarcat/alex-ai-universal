# Next.js 15 Universal Styling System - Setup Guide

## Quick Installation

### 1. Install Dependencies

```bash
npm install next-themes clsx tailwind-merge
# or
yarn add next-themes clsx tailwind-merge
# or
pnpm add next-themes clsx tailwind-merge
```

### 2. Copy Files to Your Project

Copy the following files from this package into your Next.js project:

```
your-project/
├── app/
│   ├── globals.css          ← Copy from outputs
│   └── layout.tsx           ← Update with ThemeProvider
├── components/
│   ├── theme-provider.tsx   ← Copy from outputs/components
│   ├── theme-switcher.tsx   ← Copy from outputs/components
│   └── ui.tsx               ← Copy from outputs/components
└── tailwind.config.ts       ← Update with configuration
```

### 3. Update Tailwind Config

Replace your `tailwind.config.ts` with this configuration:

```typescript
import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        border: 'var(--border)',
        input: 'var(--input)',
        ring: 'var(--ring)',
        background: 'var(--background)',
        foreground: 'var(--foreground)',
        primary: {
          DEFAULT: 'var(--primary)',
          foreground: 'var(--primary-foreground)',
        },
        secondary: {
          DEFAULT: 'var(--secondary)',
          foreground: 'var(--secondary-foreground)',
        },
        accent: {
          DEFAULT: 'var(--accent)',
          foreground: 'var(--accent-foreground)',
        },
        muted: {
          DEFAULT: 'var(--muted)',
          foreground: 'var(--muted-foreground)',
        },
        card: {
          DEFAULT: 'var(--card)',
          foreground: 'var(--card-foreground)',
        },
      },
      borderRadius: {
        lg: 'var(--radius-lg)',
        md: 'var(--radius-md)',
        sm: 'var(--radius-sm)',
      },
    },
  },
  plugins: [],
}
export default config
```

### 4. Update Root Layout

Update your `app/layout.tsx`:

```typescript
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { ThemeSwitcher } from "@/components/theme-switcher"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Your App Name",
  description: "Your app description",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider>
          {children}
          <ThemeSwitcher />
        </ThemeProvider>
      </body>
    </html>
  )
}
```

### 5. Use Components in Your Pages

```typescript
import { Card, Button, Input, Heading } from "@/components/ui"

export default function Page() {
  return (
    <main className="min-h-screen p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <Heading level={1}>Welcome</Heading>
        
        <Card>
          <Heading level={3} className="mb-4">
            Get Started
          </Heading>
          <p className="text-muted-foreground mb-4">
            This card will automatically adapt to all 10 themes!
          </p>
          <Button variant="primary">
            Click Me
          </Button>
        </Card>
      </div>
    </main>
  )
}
```

---

## Available Themes

| Theme | Value | Best For |
|-------|-------|----------|
| 🪟 Glassmorphism Modern | `glassmorphism` | SaaS dashboards, modern web apps |
| 🎨 Soft Neumorphism | `neumorphism` | Wellness apps, design tools |
| ⚡ Neubrutalism Bold | `neubrutalism` | Creative agencies, startups |
| 📱 Material Design 3 | `material` | Enterprise apps, productivity tools |
| 🌙 Midnight Dark | `midnight` | Gaming, developer tools |
| 🌸 Pastel Minimalism | `pastel` | E-commerce, lifestyle brands |
| 🌈 Gradient Fusion | `gradient` | Creative portfolios, marketing |
| 💼 Corporate Professional | `corporate` | Financial services, B2B |
| 🌿 Organic Nature | `organic` | Eco-brands, food & beverage |
| 🔮 Cyberpunk Neon | `cyberpunk` | Gaming, crypto/web3, AI tools |

---

## Customization

### Changing Default Theme

Edit `components/theme-provider.tsx`:

```typescript
<NextThemesProvider
  attribute="data-theme"
  defaultTheme="midnight"  // Change this
  enableSystem={false}
  themes={[...]}
>
```

### Creating Custom Colors

Add to `app/globals.css`:

```css
[data-theme="my-custom-theme"] {
  --background: oklch(0.95 0.01 200);
  --foreground: oklch(0.20 0.02 200);
  /* ... other variables */
}
```

Then add to theme list in `theme-provider.tsx`:

```typescript
themes={[
  'glassmorphism',
  // ... other themes
  'my-custom-theme'  // Add here
]}
```

### Modifying Existing Theme

Find the theme in `globals.css` and update CSS variables:

```css
[data-theme="glassmorphism"] {
  --primary: oklch(0.70 0.30 265);  /* Make primary brighter */
  /* ... other variables */
}
```

---

## Component Reference

### Card
```typescript
<Card className="...">
  Content goes here
</Card>
```

### Button
```typescript
<Button 
  variant="primary" | "secondary" | "accent" | "ghost" | "outline"
  size="sm" | "md" | "lg"
>
  Click Me
</Button>
```

### Input
```typescript
<Input 
  type="text"
  placeholder="Enter text..."
/>
```

### Textarea
```typescript
<Textarea 
  placeholder="Enter message..."
/>
```

### Badge
```typescript
<Badge variant="default" | "primary" | "secondary" | "accent">
  New
</Badge>
```

### Alert
```typescript
<Alert type="info" | "success" | "warning" | "error">
  Message here
</Alert>
```

### Heading
```typescript
<Heading level={1} | {2} | {3} | {4} | {5} | {6}>
  Title
</Heading>
```

### Container
```typescript
<Container>
  Content centered with max-width
</Container>
```

### Section
```typescript
<Section>
  Content with vertical padding
</Section>
```

### Grid
```typescript
<Grid cols={3} gap={6}>
  <Card>Item 1</Card>
  <Card>Item 2</Card>
  <Card>Item 3</Card>
</Grid>
```

---

## Programmatic Theme Switching

Use the `useTheme` hook:

```typescript
"use client"

import { useTheme } from "next-themes"

export function MyComponent() {
  const { theme, setTheme } = useTheme()

  return (
    <button onClick={() => setTheme('midnight')}>
      Switch to Midnight Theme
    </button>
  )
}
```

---

## TypeScript Support

Create `types/theme.d.ts`:

```typescript
export type Theme = 
  | 'glassmorphism'
  | 'neumorphism'
  | 'neubrutalism'
  | 'material'
  | 'midnight'
  | 'pastel'
  | 'gradient'
  | 'corporate'
  | 'organic'
  | 'cyberpunk'
```

---

## Best Practices

1. **Always use CSS variables** for colors instead of hardcoding
   ```typescript
   // ✅ Good
   className="bg-primary text-primary-foreground"
   
   // ❌ Bad
   className="bg-blue-500 text-white"
   ```

2. **Test on all themes** before deploying
3. **Use semantic color names** (primary, secondary, accent) instead of color names
4. **Maintain accessible contrast** in custom themes
5. **Add `suppressHydrationWarning`** to `<html>` tag to prevent hydration mismatches

---

## Troubleshooting

### Theme not changing
- Ensure `suppressHydrationWarning` is on `<html>` tag
- Check that CSS variables are defined in globals.css
- Verify theme name matches exactly in theme list

### Colors not showing
- Clear browser cache
- Check that Tailwind is processing CSS variables
- Ensure `extend` is in Tailwind config

### Hydration errors
- Add `suppressHydrationWarning` to html tag
- Use `mounted` state before rendering theme-dependent content
- Check that ThemeProvider wraps your entire app

---

## Examples

See `app/demo/page.tsx` for a comprehensive demo of all themes and components.

---

## Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [next-themes GitHub](https://github.com/pacocoursey/next-themes)
- [shadcn/ui](https://ui.shadcn.com)
- [OKLCH Color Picker](https://oklch.com)

---

## License

MIT - Free to use in personal and commercial projects

---

## Support

For issues or questions:
- Check the documentation above
- Review the demo page
- Search existing GitHub issues
- Create a new issue with reproduction steps

---

**Version:** 1.0.0  
**Last Updated:** October 2025  
**Compatible:** Next.js 15+, React 19+, Tailwind CSS 4+
