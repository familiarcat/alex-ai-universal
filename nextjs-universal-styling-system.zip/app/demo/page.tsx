import { 
  Card, 
  Button, 
  Input, 
  Textarea, 
  Badge, 
  Alert, 
  Container, 
  Section, 
  Grid, 
  Heading,
  Separator 
} from "@/components/ui"

export default function DemoPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <Section className="pt-20">
        <Container>
          <div className="text-center space-y-6">
            <Badge variant="primary">Next.js 15 + Tailwind CSS 4</Badge>
            <Heading level={1}>
              Universal Styling System
            </Heading>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              10 modern, production-ready themes for your Next.js applications.
              Switch themes instantly using the button in the bottom-right corner.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button variant="primary" size="lg">Get Started</Button>
              <Button variant="outline" size="lg">View on GitHub</Button>
            </div>
          </div>
        </Container>
      </Section>

      <Separator className="my-12" />

      {/* Features Grid */}
      <Section>
        <Container>
          <Heading level={2} className="text-center mb-12">
            Key Features
          </Heading>
          <Grid cols={3} gap={6}>
            <Card>
              <div className="text-3xl mb-4">🎨</div>
              <Heading level={4} className="mb-2">10 Modern Themes</Heading>
              <p className="text-muted-foreground">
                From Glassmorphism to Cyberpunk, choose the perfect aesthetic for your brand.
              </p>
            </Card>

            <Card>
              <div className="text-3xl mb-4">⚡</div>
              <Heading level={4} className="mb-2">Instant Switching</Heading>
              <p className="text-muted-foreground">
                CSS variables enable zero-latency theme changes with no page reload.
              </p>
            </Card>

            <Card>
              <div className="text-3xl mb-4">♿</div>
              <Heading level={4} className="mb-2">Accessible</Heading>
              <p className="text-muted-foreground">
                All themes maintain WCAG AA contrast ratios for better accessibility.
              </p>
            </Card>

            <Card>
              <div className="text-3xl mb-4">📱</div>
              <Heading level={4} className="mb-2">Fully Responsive</Heading>
              <p className="text-muted-foreground">
                Optimized for all screen sizes from mobile to desktop.
              </p>
            </Card>

            <Card>
              <div className="text-3xl mb-4">🔧</div>
              <Heading level={4} className="mb-2">Customizable</Heading>
              <p className="text-muted-foreground">
                Easy to extend with your own colors and styles using CSS variables.
              </p>
            </Card>

            <Card>
              <div className="text-3xl mb-4">🚀</div>
              <Heading level={4} className="mb-2">Production Ready</Heading>
              <p className="text-muted-foreground">
                Battle-tested components ready for your next production app.
              </p>
            </Card>
          </Grid>
        </Container>
      </Section>

      {/* Theme Showcase */}
      <Section className="bg-muted/30">
        <Container>
          <Heading level={2} className="text-center mb-4">
            Theme Gallery
          </Heading>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Explore our carefully crafted themes. Click the theme switcher to preview each one.
          </p>

          <Grid cols={2} gap={6}>
            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🪟</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Glassmorphism Modern</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Frosted glass effects with transparency and depth through layering
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Blur Effects</Badge>
                    <Badge variant="secondary">Translucent</Badge>
                    <Badge variant="accent">Layered</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🎨</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Soft Neumorphism</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Tactile 3D effects with subtle shadows and highlights
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Soft Shadows</Badge>
                    <Badge variant="secondary">3D Effect</Badge>
                    <Badge variant="accent">Minimal</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">⚡</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Neubrutalism Bold</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Raw design with thick borders and vibrant flat colors
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Bold</Badge>
                    <Badge variant="secondary">High Contrast</Badge>
                    <Badge variant="accent">Flat</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">📱</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Material Design 3</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Google's Material You with dynamic colors and elevation
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Elevation</Badge>
                    <Badge variant="secondary">Rounded</Badge>
                    <Badge variant="accent">Modern</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🌙</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Midnight Dark</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Deep dark theme with neon accents and high contrast
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Dark Mode</Badge>
                    <Badge variant="secondary">Neon</Badge>
                    <Badge variant="accent">Glow</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🌸</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Pastel Minimalism</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Soft pastels with generous whitespace and gentle aesthetics
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Pastel</Badge>
                    <Badge variant="secondary">Minimal</Badge>
                    <Badge variant="accent">Soft</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🌈</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Gradient Fusion</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Vibrant multi-color gradients with dynamic visuals
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Gradients</Badge>
                    <Badge variant="secondary">Colorful</Badge>
                    <Badge variant="accent">Dynamic</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">💼</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Corporate Professional</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Clean blue/gray palette perfect for enterprise
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Professional</Badge>
                    <Badge variant="secondary">Clean</Badge>
                    <Badge variant="accent">Enterprise</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🌿</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Organic Nature</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Earth tones with natural textures and warm colors
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Natural</Badge>
                    <Badge variant="secondary">Earth Tones</Badge>
                    <Badge variant="accent">Warm</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-start gap-4">
                <div className="text-4xl">🔮</div>
                <div className="flex-1">
                  <Heading level={4} className="mb-2">Cyberpunk Neon</Heading>
                  <p className="text-sm text-muted-foreground mb-3">
                    Futuristic with vibrant neon and tech aesthetics
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="primary">Futuristic</Badge>
                    <Badge variant="secondary">Neon</Badge>
                    <Badge variant="accent">Tech</Badge>
                  </div>
                </div>
              </div>
            </Card>
          </Grid>
        </Container>
      </Section>

      {/* Component Demo */}
      <Section>
        <Container>
          <Heading level={2} className="text-center mb-12">
            Interactive Components
          </Heading>
          
          <div className="space-y-8">
            {/* Buttons */}
            <Card>
              <Heading level={3} className="mb-6">Buttons</Heading>
              <div className="flex flex-wrap gap-4">
                <Button variant="primary">Primary</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="accent">Accent</Button>
                <Button variant="outline">Outline</Button>
                <Button variant="ghost">Ghost</Button>
              </div>
              <div className="flex flex-wrap gap-4 mt-4">
                <Button variant="primary" size="sm">Small</Button>
                <Button variant="primary" size="md">Medium</Button>
                <Button variant="primary" size="lg">Large</Button>
              </div>
            </Card>

            {/* Form Elements */}
            <Card>
              <Heading level={3} className="mb-6">Form Elements</Heading>
              <div className="space-y-4 max-w-xl">
                <div>
                  <label className="block text-sm font-medium mb-2">Email Address</label>
                  <Input type="email" placeholder="you@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <Textarea placeholder="Type your message here..." />
                </div>
                <Button variant="primary">Submit</Button>
              </div>
            </Card>

            {/* Alerts */}
            <Card>
              <Heading level={3} className="mb-6">Alerts</Heading>
              <div className="space-y-4">
                <Alert type="info">
                  <strong>Info:</strong> This is an informational message.
                </Alert>
                <Alert type="success">
                  <strong>Success:</strong> Your action was completed successfully.
                </Alert>
                <Alert type="warning">
                  <strong>Warning:</strong> Please review this important information.
                </Alert>
                <Alert type="error">
                  <strong>Error:</strong> An error occurred. Please try again.
                </Alert>
              </div>
            </Card>

            {/* Badges */}
            <Card>
              <Heading level={3} className="mb-6">Badges</Heading>
              <div className="flex flex-wrap gap-3">
                <Badge variant="default">Default</Badge>
                <Badge variant="primary">Primary</Badge>
                <Badge variant="secondary">Secondary</Badge>
                <Badge variant="accent">Accent</Badge>
              </div>
            </Card>
          </div>
        </Container>
      </Section>

      {/* CTA Section */}
      <Section className="bg-muted/30">
        <Container>
          <div className="text-center space-y-6 py-12">
            <Heading level={2}>
              Ready to Get Started?
            </Heading>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Install the package and start building beautiful, themeable Next.js applications today.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button variant="primary" size="lg">Documentation</Button>
              <Button variant="outline" size="lg">View Examples</Button>
            </div>
          </div>
        </Container>
      </Section>

      {/* Footer */}
      <footer className="border-t-2 border-border py-8">
        <Container>
          <div className="text-center text-muted-foreground text-sm">
            <p>Built with Next.js 15, Tailwind CSS 4, and TypeScript</p>
            <p className="mt-2">Universal Styling System © 2025</p>
          </div>
        </Container>
      </footer>
    </main>
  )
}
