"use client"

import * as React from "react"
import { useTheme } from "next-themes"

const themes = [
  { 
    value: 'glassmorphism', 
    label: 'Glassmorphism Modern', 
    icon: '🪟',
    description: 'Frosted glass with blur effects'
  },
  { 
    value: 'neumorphism', 
    label: 'Soft Neumorphism', 
    icon: '🎨',
    description: 'Soft 3D with subtle shadows'
  },
  { 
    value: 'neubrutalism', 
    label: 'Neubrutalism Bold', 
    icon: '⚡',
    description: 'Bold colors with thick borders'
  },
  { 
    value: 'material', 
    label: 'Material Design 3', 
    icon: '📱',
    description: 'Google Material You'
  },
  { 
    value: 'midnight', 
    label: 'Midnight Dark', 
    icon: '🌙',
    description: 'Deep dark with neon accents'
  },
  { 
    value: 'pastel', 
    label: 'Pastel Minimalism', 
    icon: '🌸',
    description: 'Soft pastels with whitespace'
  },
  { 
    value: 'gradient', 
    label: 'Gradient Fusion', 
    icon: '🌈',
    description: 'Vibrant multi-color gradients'
  },
  { 
    value: 'corporate', 
    label: 'Corporate Professional', 
    icon: '💼',
    description: 'Clean blue/gray enterprise'
  },
  { 
    value: 'organic', 
    label: 'Organic Nature', 
    icon: '🌿',
    description: 'Earth tones and natural feel'
  },
  { 
    value: 'cyberpunk', 
    label: 'Cyberpunk Neon', 
    icon: '🔮',
    description: 'Futuristic neon aesthetics'
  },
]

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  const [isOpen, setIsOpen] = React.useState(false)

  // Prevent hydration mismatch
  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const currentTheme = themes.find(t => t.value === theme)

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Theme Switcher */}
      <div className="fixed bottom-8 right-8 z-50">
        {/* Theme Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-4 rounded-lg bg-card border-2 border-border shadow-xl hover:scale-105 transition-all duration-200 flex items-center gap-2"
          aria-label="Change theme"
        >
          <span className="text-2xl">{currentTheme?.icon || '🎨'}</span>
          <span className="text-sm font-medium hidden md:block">Theme</span>
        </button>

        {/* Theme Menu */}
        {isOpen && (
          <div className="absolute bottom-full right-0 mb-2 w-80 max-w-[calc(100vw-4rem)]">
            <div className="bg-card border-2 border-border rounded-lg shadow-2xl overflow-hidden">
              {/* Header */}
              <div className="px-4 py-3 bg-muted border-b-2 border-border">
                <h3 className="text-sm font-semibold text-foreground">Choose Your Theme</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Select from 10 modern design styles
                </p>
              </div>

              {/* Theme List */}
              <div className="max-h-[60vh] overflow-y-auto p-2">
                {themes.map((themeOption) => (
                  <button
                    key={themeOption.value}
                    onClick={() => {
                      setTheme(themeOption.value)
                      setIsOpen(false)
                    }}
                    className={`w-full text-left px-3 py-3 rounded-md transition-all duration-150 flex items-start gap-3 group ${
                      theme === themeOption.value 
                        ? 'bg-primary text-primary-foreground shadow-md' 
                        : 'hover:bg-accent hover:text-accent-foreground'
                    }`}
                  >
                    <span className="text-2xl flex-shrink-0">{themeOption.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{themeOption.label}</div>
                      <div className={`text-xs mt-0.5 ${
                        theme === themeOption.value 
                          ? 'opacity-90' 
                          : 'text-muted-foreground'
                      }`}>
                        {themeOption.description}
                      </div>
                    </div>
                    {theme === themeOption.value && (
                      <span className="text-lg">✓</span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
