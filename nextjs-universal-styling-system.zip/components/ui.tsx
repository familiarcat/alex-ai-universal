import React from 'react'

// Card Component
export function Card({ 
  children, 
  className = "",
  ...props 
}: { 
  children: React.ReactNode
  className?: string
  [key: string]: any
}) {
  return (
    <div 
      className={`bg-card text-card-foreground rounded-lg border-2 border-border p-6 shadow-sm ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}

// Button Component
export function Button({ 
  children, 
  variant = "primary",
  size = "md",
  className = "",
  ...props
}: { 
  children: React.ReactNode
  variant?: "primary" | "secondary" | "accent" | "ghost" | "outline"
  size?: "sm" | "md" | "lg"
  className?: string
  [key: string]: any
}) {
  const variantClasses = {
    primary: "bg-primary text-primary-foreground hover:opacity-90",
    secondary: "bg-secondary text-secondary-foreground hover:opacity-90",
    accent: "bg-accent text-accent-foreground hover:opacity-90",
    ghost: "bg-transparent hover:bg-accent hover:text-accent-foreground",
    outline: "bg-transparent border-2 border-border hover:bg-accent hover:text-accent-foreground"
  }

  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  }

  return (
    <button 
      className={`rounded-md font-medium transition-all duration-150 ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}

// Input Component
export function Input({ 
  type = "text",
  className = "",
  ...props
}: {
  type?: string
  className?: string
  [key: string]: any
}) {
  return (
    <input
      type={type}
      className={`w-full px-4 py-2 bg-input border-2 border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-all ${className}`}
      {...props}
    />
  )
}

// Textarea Component
export function Textarea({ 
  className = "",
  ...props
}: {
  className?: string
  [key: string]: any
}) {
  return (
    <textarea
      className={`w-full px-4 py-2 bg-input border-2 border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground min-h-[100px] transition-all ${className}`}
      {...props}
    />
  )
}

// Badge Component
export function Badge({
  children,
  variant = "default",
  className = ""
}: {
  children: React.ReactNode
  variant?: "default" | "primary" | "secondary" | "accent"
  className?: string
}) {
  const variantClasses = {
    default: "bg-muted text-muted-foreground",
    primary: "bg-primary text-primary-foreground",
    secondary: "bg-secondary text-secondary-foreground",
    accent: "bg-accent text-accent-foreground"
  }

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${variantClasses[variant]} ${className}`}>
      {children}
    </span>
  )
}

// Alert Component
export function Alert({
  children,
  type = "info",
  className = ""
}: {
  children: React.ReactNode
  type?: "info" | "success" | "warning" | "error"
  className?: string
}) {
  const typeClasses = {
    info: "bg-blue-50 border-blue-200 text-blue-900 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-100",
    success: "bg-green-50 border-green-200 text-green-900 dark:bg-green-900/20 dark:border-green-800 dark:text-green-100",
    warning: "bg-yellow-50 border-yellow-200 text-yellow-900 dark:bg-yellow-900/20 dark:border-yellow-800 dark:text-yellow-100",
    error: "bg-red-50 border-red-200 text-red-900 dark:bg-red-900/20 dark:border-red-800 dark:text-red-100"
  }

  return (
    <div className={`p-4 rounded-lg border-2 ${typeClasses[type]} ${className}`}>
      {children}
    </div>
  )
}

// Container Component
export function Container({
  children,
  className = ""
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${className}`}>
      {children}
    </div>
  )
}

// Section Component
export function Section({
  children,
  className = ""
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <section className={`py-12 md:py-16 lg:py-20 ${className}`}>
      {children}
    </section>
  )
}

// Grid Component
export function Grid({
  children,
  cols = 3,
  gap = 6,
  className = ""
}: {
  children: React.ReactNode
  cols?: 1 | 2 | 3 | 4
  gap?: number
  className?: string
}) {
  const colsClasses = {
    1: "grid-cols-1",
    2: "grid-cols-1 md:grid-cols-2",
    3: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
    4: "grid-cols-1 md:grid-cols-2 lg:grid-cols-4"
  }

  return (
    <div className={`grid ${colsClasses[cols]} gap-${gap} ${className}`}>
      {children}
    </div>
  )
}

// Heading Component
export function Heading({
  children,
  level = 1,
  className = ""
}: {
  children: React.ReactNode
  level?: 1 | 2 | 3 | 4 | 5 | 6
  className?: string
}) {
  const Tag = `h${level}` as keyof JSX.IntrinsicElements
  
  const levelClasses = {
    1: "text-4xl md:text-5xl font-bold",
    2: "text-3xl md:text-4xl font-bold",
    3: "text-2xl md:text-3xl font-semibold",
    4: "text-xl md:text-2xl font-semibold",
    5: "text-lg md:text-xl font-medium",
    6: "text-base md:text-lg font-medium"
  }

  return (
    <Tag className={`${levelClasses[level]} ${className}`}>
      {children}
    </Tag>
  )
}

// Separator Component
export function Separator({
  orientation = "horizontal",
  className = ""
}: {
  orientation?: "horizontal" | "vertical"
  className?: string
}) {
  return (
    <div
      className={`bg-border ${
        orientation === "horizontal" 
          ? "h-[2px] w-full" 
          : "w-[2px] h-full"
      } ${className}`}
    />
  )
}
