"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import { type ThemeProviderProps } from "next-themes/dist/types"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider
      attribute="data-theme"
      defaultTheme="glassmorphism"
      enableSystem={false}
      themes={[
        'glassmorphism',
        'neumorphism',
        'neubrutalism',
        'material',
        'midnight',
        'pastel',
        'gradient',
        'corporate',
        'organic',
        'cyberpunk'
      ]}
      {...props}
    >
      {children}
    </NextThemesProvider>
  )
}
