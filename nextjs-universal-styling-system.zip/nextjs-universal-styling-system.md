# Next.js 15 Universal Styling System
## 10 Modern Theme Options with Tailwind CSS

### Overview
This document provides a complete universal styling system for Next.js 15 applications with 10 distinct, modern design themes. Each theme is production-ready and can be easily integrated into your application using CSS variables and Tailwind CSS.

---

## Table of Contents
1. [System Architecture](#system-architecture)
2. [Theme Options](#theme-options)
3. [Implementation Guide](#implementation-guide)
4. [Code Examples](#code-examples)

---

## System Architecture

### Core Technologies
- **Next.js 15** with App Router
- **Tailwind CSS 4** with CSS Variables
- **CSS Custom Properties** for dynamic theming
- **next-themes** for theme switching

### File Structure
```
app/
├── globals.css          # Global styles with theme variables
├── layout.tsx           # Root layout with ThemeProvider
├── components/
│   ├── theme-provider.tsx
│   └── theme-switcher.tsx
└── styles/
    └── themes/
        ├── theme-1-glassmorphism.css
        ├── theme-2-neumorphism.css
        └── ... (10 theme files)
```

---

## Theme Options

### Theme 1: **Glassmorphism Modern** 🪟
**Design Philosophy**: Frosted glass effects with transparency and blur, creating depth through layering.

**Color Palette**:
- Primary: `oklch(0.65 0.25 265)` - Deep violet
- Secondary: `oklch(0.75 0.15 285)` - Soft lavender  
- Accent: `oklch(0.80 0.20 310)` - Pink gradient
- Background: `oklch(0.20 0.02 265)` - Dark base
- Surface: `rgba(255, 255, 255, 0.1)` - Glass panels

**Key Characteristics**:
- Backdrop blur effects
- Translucent surfaces
- Vibrant gradient backgrounds
- Multi-layered UI elements
- Soft borders with transparency

**Best For**: SaaS dashboards, modern web apps, fintech platforms

---

### Theme 2: **Soft Neumorphism** 🎨
**Design Philosophy**: Soft UI with subtle shadows and highlights creating tactile 3D effects.

**Color Palette**:
- Primary: `oklch(0.70 0.05 220)` - Soft blue-gray
- Secondary: `oklch(0.65 0.03 220)` - Muted gray
- Accent: `oklch(0.75 0.10 250)` - Gentle purple
- Background: `oklch(0.90 0.01 220)` - Light neutral
- Shadow Light: `rgba(255, 255, 255, 0.9)`
- Shadow Dark: `rgba(0, 0, 0, 0.1)`

**Key Characteristics**:
- Extruded/embossed elements
- Monochromatic color schemes
- Soft shadows (inner & outer)
- Minimal contrast
- Tactile appearance

**Best For**: Wellness apps, minimalist portfolios, design tools

---

### Theme 3: **Neubrutalism Bold** ⚡
**Design Philosophy**: Raw, bold design with thick borders, flat colors, and high contrast.

**Color Palette**:
- Primary: `oklch(0.45 0.25 270)` - Electric purple
- Secondary: `oklch(0.85 0.20 100)` - Vibrant yellow
- Accent: `oklch(0.60 0.25 30)` - Coral orange
- Background: `oklch(0.98 0.01 100)` - Off-white
- Border: `oklch(0.20 0.01 270)` - Black

**Key Characteristics**:
- Thick black borders (3-5px)
- Flat, vibrant colors
- Grid-based layouts
- Brutalist typography
- No gradients or shadows
- Hard edges everywhere

**Best For**: Creative agencies, startups, social media apps

---

### Theme 4: **Material Design 3** 📱
**Design Philosophy**: Google's Material You with dynamic colors and elevation system.

**Color Palette**:
- Primary: `oklch(0.50 0.24 240)` - Material blue
- Secondary: `oklch(0.60 0.20 180)` - Teal accent
- Tertiary: `oklch(0.65 0.22 60)` - Warm yellow
- Background: `oklch(0.98 0.01 240)` - Surface
- On-Primary: `oklch(1.0 0 0)` - White text

**Key Characteristics**:
- Elevation shadows (0-5 levels)
- Rounded corners (8-28px)
- Color tokens system
- Motion/transitions
- Paper metaphor

**Best For**: Android apps, enterprise dashboards, productivity tools

---

### Theme 5: **Midnight Dark** 🌙
**Design Philosophy**: Deep dark mode with subtle neon accents and high contrast.

**Color Palette**:
- Primary: `oklch(0.65 0.28 180)` - Cyan glow
- Secondary: `oklch(0.60 0.25 300)` - Purple accent
- Accent: `oklch(0.70 0.25 140)` - Neon green
- Background: `oklch(0.15 0.01 240)` - True dark
- Surface: `oklch(0.20 0.02 240)` - Card background

**Key Characteristics**:
- True black backgrounds
- Neon accent colors
- Subtle glow effects
- High contrast text
- Dark surfaces with depth

**Best For**: Gaming apps, developer tools, creative software

---

### Theme 6: **Pastel Minimalism** 🌸
**Design Philosophy**: Soft pastels with generous whitespace and gentle aesthetics.

**Color Palette**:
- Primary: `oklch(0.85 0.08 320)` - Soft pink
- Secondary: `oklch(0.88 0.06 280)` - Lavender mist
- Accent: `oklch(0.90 0.05 140)` - Mint cream
- Background: `oklch(0.98 0.01 60)` - Warm white
- Text: `oklch(0.35 0.02 280)` - Soft charcoal

**Key Characteristics**:
- Muted pastel colors
- Generous spacing
- Soft shadows
- Rounded elements
- Minimal UI patterns

**Best For**: E-commerce, lifestyle brands, wellness apps

---

### Theme 7: **Gradient Fusion** 🌈
**Design Philosophy**: Vibrant multi-color gradients with dynamic, eye-catching visuals.

**Color Palette**:
- Primary Gradient: `linear-gradient(135deg, oklch(0.65 0.28 330), oklch(0.70 0.25 270))`
- Secondary Gradient: `linear-gradient(135deg, oklch(0.60 0.25 200), oklch(0.70 0.28 160))`
- Accent: `oklch(0.75 0.25 45)` - Orange burst
- Background: `oklch(0.15 0.02 270)` - Dark gradient base
- Surface: Gradient overlays

**Key Characteristics**:
- Complex gradient transitions
- Layered gradient backgrounds
- Mesh gradients
- Animated gradient shifts
- 3D gradient effects

**Best For**: Creative portfolios, entertainment apps, marketing sites

---

### Theme 8: **Corporate Professional** 💼
**Design Philosophy**: Clean, trustworthy design with blue/gray palette for enterprise.

**Color Palette**:
- Primary: `oklch(0.45 0.15 240)` - Corporate blue
- Secondary: `oklch(0.55 0.08 240)` - Steel gray
- Accent: `oklch(0.70 0.12 180)` - Professional teal
- Background: `oklch(0.97 0.00 240)` - Clean white
- Border: `oklch(0.85 0.01 240)` - Subtle dividers

**Key Characteristics**:
- Conservative color palette
- Grid-based layouts
- Clear hierarchy
- Accessible contrast
- Professional typography

**Best For**: Financial services, corporate sites, B2B platforms

---

### Theme 9: **Organic Nature** 🌿
**Design Philosophy**: Earth tones with natural textures and warm, welcoming colors.

**Color Palette**:
- Primary: `oklch(0.50 0.15 140)` - Forest green
- Secondary: `oklch(0.60 0.18 80)` - Warm terracotta
- Accent: `oklch(0.70 0.12 60)` - Golden wheat
- Background: `oklch(0.95 0.02 80)` - Cream base
- Text: `oklch(0.30 0.04 80)` - Rich brown

**Key Characteristics**:
- Earthy color palette
- Organic shapes
- Natural textures
- Warm tones
- Sustainable feel

**Best For**: Eco-brands, food & beverage, wellness, sustainability apps

---

### Theme 10: **Cyberpunk Neon** ⚡🔮
**Design Philosophy**: Futuristic with vibrant neon colors, dark backgrounds, and tech aesthetic.

**Color Palette**:
- Primary: `oklch(0.70 0.30 330)` - Hot pink
- Secondary: `oklch(0.65 0.28 280)` - Electric purple
- Accent: `oklch(0.75 0.30 180)` - Cyan glow
- Background: `oklch(0.10 0.02 280)` - Deep black
- Glow: Neon box-shadows

**Key Characteristics**:
- High contrast neon colors
- Glowing effects (box-shadow)
- Dark, moody backgrounds
- Tech-inspired UI
- Futuristic typography

**Best For**: Gaming, crypto/web3, tech startups, AI tools

---

## Implementation Guide

### Step 1: Install Dependencies

```bash
npm install next-themes class-variance-authority clsx tailwind-merge
```

### Step 2: Configure Tailwind (tailwind.config.ts)

```typescript
import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        border: 'var(--border)',
        input: 'var(--input)',
        ring: 'var(--ring)',
        background: 'var(--background)',
        foreground: 'var(--foreground)',
        primary: {
          DEFAULT: 'var(--primary)',
          foreground: 'var(--primary-foreground)',
        },
        secondary: {
          DEFAULT: 'var(--secondary)',
          foreground: 'var(--secondary-foreground)',
        },
        accent: {
          DEFAULT: 'var(--accent)',
          foreground: 'var(--accent-foreground)',
        },
        muted: {
          DEFAULT: 'var(--muted)',
          foreground: 'var(--muted-foreground)',
        },
        card: {
          DEFAULT: 'var(--card)',
          foreground: 'var(--card-foreground)',
        },
      },
      borderRadius: {
        lg: 'var(--radius-lg)',
        md: 'var(--radius-md)',
        sm: 'var(--radius-sm)',
      },
    },
  },
  plugins: [],
}
export default config
```

### Step 3: Create Base Styles (app/globals.css)

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  * {
    @apply border-border;
  }
  
  body {
    @apply bg-background text-foreground;
    font-feature-settings: "rlig" 1, "calt" 1;
  }
}

/* Base Theme Variables */
:root {
  --background: oklch(0.98 0.01 240);
  --foreground: oklch(0.20 0.02 240);
  
  --card: oklch(1.0 0 0);
  --card-foreground: oklch(0.20 0.02 240);
  
  --primary: oklch(0.50 0.24 240);
  --primary-foreground: oklch(1.0 0 0);
  
  --secondary: oklch(0.90 0.02 240);
  --secondary-foreground: oklch(0.20 0.02 240);
  
  --accent: oklch(0.95 0.02 240);
  --accent-foreground: oklch(0.20 0.02 240);
  
  --muted: oklch(0.95 0.01 240);
  --muted-foreground: oklch(0.50 0.02 240);
  
  --border: oklch(0.90 0.01 240);
  --input: oklch(0.90 0.01 240);
  --ring: oklch(0.50 0.24 240);
  
  --radius-lg: 16px;
  --radius-md: 8px;
  --radius-sm: 4px;
}

/* Theme 1: Glassmorphism Modern */
[data-theme="glassmorphism"] {
  --background: oklch(0.20 0.02 265);
  --foreground: oklch(0.95 0.01 265);
  
  --card: rgba(255, 255, 255, 0.1);
  --card-foreground: oklch(0.95 0.01 265);
  
  --primary: oklch(0.65 0.25 265);
  --primary-foreground: oklch(1.0 0 0);
  
  --secondary: oklch(0.75 0.15 285);
  --secondary-foreground: oklch(0.98 0.01 285);
  
  --accent: oklch(0.80 0.20 310);
  --accent-foreground: oklch(0.98 0.01 310);
  
  --muted: rgba(255, 255, 255, 0.05);
  --muted-foreground: oklch(0.70 0.02 265);
  
  --border: rgba(255, 255, 255, 0.15);
  --input: rgba(255, 255, 255, 0.1);
  --ring: oklch(0.65 0.25 265);
  
  --radius-lg: 24px;
  --radius-md: 16px;
  --radius-sm: 12px;
}

[data-theme="glassmorphism"] .glass-effect {
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.18);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
}

/* Theme 2: Soft Neumorphism */
[data-theme="neumorphism"] {
  --background: oklch(0.90 0.01 220);
  --foreground: oklch(0.30 0.02 220);
  
  --card: oklch(0.90 0.01 220);
  --card-foreground: oklch(0.30 0.02 220);
  
  --primary: oklch(0.70 0.05 220);
  --primary-foreground: oklch(0.30 0.02 220);
  
  --secondary: oklch(0.65 0.03 220);
  --secondary-foreground: oklch(0.30 0.02 220);
  
  --accent: oklch(0.75 0.10 250);
  --accent-foreground: oklch(0.30 0.02 250);
  
  --muted: oklch(0.88 0.01 220);
  --muted-foreground: oklch(0.50 0.02 220);
  
  --border: oklch(0.85 0.01 220);
  --input: oklch(0.88 0.01 220);
  --ring: oklch(0.70 0.05 220);
  
  --radius-lg: 20px;
  --radius-md: 16px;
  --radius-sm: 12px;
}

[data-theme="neumorphism"] .neomorph {
  box-shadow: 
    9px 9px 16px rgba(163, 177, 198, 0.6),
    -9px -9px 16px rgba(255, 255, 255, 0.9);
}

[data-theme="neumorphism"] .neomorph-inset {
  box-shadow: 
    inset 6px 6px 12px rgba(163, 177, 198, 0.5),
    inset -6px -6px 12px rgba(255, 255, 255, 0.8);
}

/* Theme 3: Neubrutalism Bold */
[data-theme="neubrutalism"] {
  --background: oklch(0.98 0.01 100);
  --foreground: oklch(0.20 0.01 270);
  
  --card: oklch(0.98 0.01 100);
  --card-foreground: oklch(0.20 0.01 270);
  
  --primary: oklch(0.45 0.25 270);
  --primary-foreground: oklch(0.98 0.01 100);
  
  --secondary: oklch(0.85 0.20 100);
  --secondary-foreground: oklch(0.20 0.01 270);
  
  --accent: oklch(0.60 0.25 30);
  --accent-foreground: oklch(0.98 0.01 30);
  
  --muted: oklch(0.95 0.02 100);
  --muted-foreground: oklch(0.40 0.01 270);
  
  --border: oklch(0.20 0.01 270);
  --input: oklch(0.98 0.01 100);
  --ring: oklch(0.20 0.01 270);
  
  --radius-lg: 4px;
  --radius-md: 2px;
  --radius-sm: 0px;
}

[data-theme="neubrutalism"] * {
  border-width: 3px;
  border-color: var(--border);
}

[data-theme="neubrutalism"] .brutal-shadow {
  box-shadow: 6px 6px 0px var(--border);
}

/* Theme 4: Material Design 3 */
[data-theme="material"] {
  --background: oklch(0.98 0.01 240);
  --foreground: oklch(0.20 0.02 240);
  
  --card: oklch(1.0 0 0);
  --card-foreground: oklch(0.20 0.02 240);
  
  --primary: oklch(0.50 0.24 240);
  --primary-foreground: oklch(1.0 0 0);
  
  --secondary: oklch(0.60 0.20 180);
  --secondary-foreground: oklch(1.0 0 0);
  
  --accent: oklch(0.65 0.22 60);
  --accent-foreground: oklch(0.20 0.02 60);
  
  --muted: oklch(0.95 0.01 240);
  --muted-foreground: oklch(0.50 0.02 240);
  
  --border: oklch(0.90 0.01 240);
  --input: oklch(0.95 0.01 240);
  --ring: oklch(0.50 0.24 240);
  
  --radius-lg: 28px;
  --radius-md: 16px;
  --radius-sm: 8px;
}

[data-theme="material"] .elevation-1 {
  box-shadow: 0 1px 2px rgba(0,0,0,0.05), 0 1px 3px rgba(0,0,0,0.1);
}

[data-theme="material"] .elevation-2 {
  box-shadow: 0 3px 6px rgba(0,0,0,0.10), 0 3px 6px rgba(0,0,0,0.15);
}

[data-theme="material"] .elevation-3 {
  box-shadow: 0 10px 20px rgba(0,0,0,0.15), 0 6px 6px rgba(0,0,0,0.10);
}

/* Theme 5: Midnight Dark */
[data-theme="midnight"] {
  --background: oklch(0.15 0.01 240);
  --foreground: oklch(0.95 0.01 240);
  
  --card: oklch(0.20 0.02 240);
  --card-foreground: oklch(0.95 0.01 240);
  
  --primary: oklch(0.65 0.28 180);
  --primary-foreground: oklch(0.15 0.01 180);
  
  --secondary: oklch(0.60 0.25 300);
  --secondary-foreground: oklch(0.95 0.01 300);
  
  --accent: oklch(0.70 0.25 140);
  --accent-foreground: oklch(0.15 0.01 140);
  
  --muted: oklch(0.25 0.02 240);
  --muted-foreground: oklch(0.60 0.02 240);
  
  --border: oklch(0.30 0.02 240);
  --input: oklch(0.25 0.02 240);
  --ring: oklch(0.65 0.28 180);
  
  --radius-lg: 12px;
  --radius-md: 8px;
  --radius-sm: 4px;
}

[data-theme="midnight"] .neon-glow {
  box-shadow: 0 0 10px var(--primary), 0 0 20px var(--primary), 0 0 30px var(--primary);
}

/* Theme 6: Pastel Minimalism */
[data-theme="pastel"] {
  --background: oklch(0.98 0.01 60);
  --foreground: oklch(0.35 0.02 280);
  
  --card: oklch(1.0 0 0);
  --card-foreground: oklch(0.35 0.02 280);
  
  --primary: oklch(0.85 0.08 320);
  --primary-foreground: oklch(0.35 0.02 320);
  
  --secondary: oklch(0.88 0.06 280);
  --secondary-foreground: oklch(0.35 0.02 280);
  
  --accent: oklch(0.90 0.05 140);
  --accent-foreground: oklch(0.35 0.02 140);
  
  --muted: oklch(0.95 0.02 280);
  --muted-foreground: oklch(0.55 0.02 280);
  
  --border: oklch(0.92 0.02 280);
  --input: oklch(0.95 0.02 280);
  --ring: oklch(0.85 0.08 320);
  
  --radius-lg: 20px;
  --radius-md: 16px;
  --radius-sm: 12px;
}

/* Theme 7: Gradient Fusion */
[data-theme="gradient"] {
  --background: oklch(0.15 0.02 270);
  --foreground: oklch(0.95 0.01 270);
  
  --card: oklch(0.20 0.02 270);
  --card-foreground: oklch(0.95 0.01 270);
  
  --primary: oklch(0.65 0.28 330);
  --primary-foreground: oklch(0.98 0.01 330);
  
  --secondary: oklch(0.70 0.25 270);
  --secondary-foreground: oklch(0.98 0.01 270);
  
  --accent: oklch(0.75 0.25 45);
  --accent-foreground: oklch(0.20 0.02 45);
  
  --muted: oklch(0.25 0.02 270);
  --muted-foreground: oklch(0.65 0.02 270);
  
  --border: oklch(0.30 0.02 270);
  --input: oklch(0.25 0.02 270);
  --ring: oklch(0.65 0.28 330);
  
  --radius-lg: 16px;
  --radius-md: 12px;
  --radius-sm: 8px;
}

[data-theme="gradient"] .gradient-bg {
  background: linear-gradient(135deg, oklch(0.65 0.28 330), oklch(0.70 0.25 270));
}

/* Theme 8: Corporate Professional */
[data-theme="corporate"] {
  --background: oklch(0.97 0.00 240);
  --foreground: oklch(0.25 0.02 240);
  
  --card: oklch(1.0 0 0);
  --card-foreground: oklch(0.25 0.02 240);
  
  --primary: oklch(0.45 0.15 240);
  --primary-foreground: oklch(1.0 0 0);
  
  --secondary: oklch(0.55 0.08 240);
  --secondary-foreground: oklch(1.0 0 0);
  
  --accent: oklch(0.70 0.12 180);
  --accent-foreground: oklch(0.20 0.02 180);
  
  --muted: oklch(0.94 0.01 240);
  --muted-foreground: oklch(0.50 0.02 240);
  
  --border: oklch(0.85 0.01 240);
  --input: oklch(0.95 0.01 240);
  --ring: oklch(0.45 0.15 240);
  
  --radius-lg: 8px;
  --radius-md: 6px;
  --radius-sm: 4px;
}

/* Theme 9: Organic Nature */
[data-theme="organic"] {
  --background: oklch(0.95 0.02 80);
  --foreground: oklch(0.30 0.04 80);
  
  --card: oklch(0.98 0.01 80);
  --card-foreground: oklch(0.30 0.04 80);
  
  --primary: oklch(0.50 0.15 140);
  --primary-foreground: oklch(0.98 0.01 140);
  
  --secondary: oklch(0.60 0.18 80);
  --secondary-foreground: oklch(0.98 0.01 80);
  
  --accent: oklch(0.70 0.12 60);
  --accent-foreground: oklch(0.30 0.04 60);
  
  --muted: oklch(0.90 0.02 80);
  --muted-foreground: oklch(0.50 0.04 80);
  
  --border: oklch(0.85 0.03 80);
  --input: oklch(0.92 0.02 80);
  --ring: oklch(0.50 0.15 140);
  
  --radius-lg: 24px;
  --radius-md: 16px;
  --radius-sm: 12px;
}

/* Theme 10: Cyberpunk Neon */
[data-theme="cyberpunk"] {
  --background: oklch(0.10 0.02 280);
  --foreground: oklch(0.95 0.02 280);
  
  --card: oklch(0.15 0.02 280);
  --card-foreground: oklch(0.95 0.02 280);
  
  --primary: oklch(0.70 0.30 330);
  --primary-foreground: oklch(0.10 0.02 330);
  
  --secondary: oklch(0.65 0.28 280);
  --secondary-foreground: oklch(0.95 0.02 280);
  
  --accent: oklch(0.75 0.30 180);
  --accent-foreground: oklch(0.10 0.02 180);
  
  --muted: oklch(0.20 0.02 280);
  --muted-foreground: oklch(0.60 0.02 280);
  
  --border: oklch(0.30 0.05 280);
  --input: oklch(0.20 0.02 280);
  --ring: oklch(0.70 0.30 330);
  
  --radius-lg: 8px;
  --radius-md: 4px;
  --radius-sm: 2px;
}

[data-theme="cyberpunk"] .cyber-glow {
  box-shadow: 
    0 0 5px var(--primary),
    0 0 10px var(--primary),
    0 0 20px var(--primary),
    0 0 40px var(--secondary);
  text-shadow: 0 0 5px var(--primary);
}

@layer utilities {
  .text-balance {
    text-wrap: balance;
  }
}
```

### Step 4: Create Theme Provider (components/theme-provider.tsx)

```typescript
"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import { type ThemeProviderProps } from "next-themes/dist/types"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider
      attribute="data-theme"
      defaultTheme="glassmorphism"
      enableSystem={false}
      themes={[
        'glassmorphism',
        'neumorphism',
        'neubrutalism',
        'material',
        'midnight',
        'pastel',
        'gradient',
        'corporate',
        'organic',
        'cyberpunk'
      ]}
      {...props}
    >
      {children}
    </NextThemesProvider>
  )
}
```

### Step 5: Create Theme Switcher (components/theme-switcher.tsx)

```typescript
"use client"

import * as React from "react"
import { useTheme } from "next-themes"

const themes = [
  { value: 'glassmorphism', label: '🪟 Glassmorphism Modern', icon: '🪟' },
  { value: 'neumorphism', label: '🎨 Soft Neumorphism', icon: '🎨' },
  { value: 'neubrutalism', label: '⚡ Neubrutalism Bold', icon: '⚡' },
  { value: 'material', label: '📱 Material Design 3', icon: '📱' },
  { value: 'midnight', label: '🌙 Midnight Dark', icon: '🌙' },
  { value: 'pastel', label: '🌸 Pastel Minimalism', icon: '🌸' },
  { value: 'gradient', label: '🌈 Gradient Fusion', icon: '🌈' },
  { value: 'corporate', label: '💼 Corporate Professional', icon: '💼' },
  { value: 'organic', label: '🌿 Organic Nature', icon: '🌿' },
  { value: 'cyberpunk', label: '⚡🔮 Cyberpunk Neon', icon: '🔮' },
]

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  // Prevent hydration mismatch
  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="fixed bottom-8 right-8 z-50">
      <div className="relative group">
        {/* Theme Button */}
        <button
          className="p-4 rounded-lg bg-card border-2 border-border shadow-lg hover:scale-105 transition-transform"
          aria-label="Change theme"
        >
          <span className="text-2xl">
            {themes.find(t => t.value === theme)?.icon || '🎨'}
          </span>
        </button>

        {/* Theme Menu */}
        <div className="absolute bottom-full right-0 mb-2 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
          <div className="bg-card border-2 border-border rounded-lg shadow-2xl p-2 max-h-96 overflow-y-auto">
            <div className="text-sm font-semibold px-3 py-2 text-muted-foreground">
              Choose Theme
            </div>
            {themes.map((themeOption) => (
              <button
                key={themeOption.value}
                onClick={() => setTheme(themeOption.value)}
                className={`w-full text-left px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground transition-colors flex items-center gap-2 ${
                  theme === themeOption.value ? 'bg-primary text-primary-foreground' : ''
                }`}
              >
                <span className="text-lg">{themeOption.icon}</span>
                <span className="text-sm">{themeOption.label.split(' ').slice(1).join(' ')}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
```

### Step 6: Update Root Layout (app/layout.tsx)

```typescript
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { ThemeSwitcher } from "@/components/theme-switcher"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Next.js Universal Styling System",
  description: "10 Modern Themes for Next.js 15 Applications",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider>
          {children}
          <ThemeSwitcher />
        </ThemeProvider>
      </body>
    </html>
  )
}
```

---

## Code Examples

### Example 1: Card Component

```typescript
export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-card text-card-foreground rounded-lg border-2 border-border p-6 ${className}`}>
      {children}
    </div>
  )
}
```

### Example 2: Button Component

```typescript
export function Button({ 
  children, 
  variant = "primary", 
  className = "" 
}: { 
  children: React.ReactNode; 
  variant?: "primary" | "secondary" | "accent";
  className?: string;
}) {
  const variantClasses = {
    primary: "bg-primary text-primary-foreground hover:opacity-90",
    secondary: "bg-secondary text-secondary-foreground hover:opacity-90",
    accent: "bg-accent text-accent-foreground hover:opacity-90"
  }

  return (
    <button 
      className={`px-6 py-3 rounded-md font-medium transition-all ${variantClasses[variant]} ${className}`}
    >
      {children}
    </button>
  )
}
```

### Example 3: Input Component

```typescript
export function Input({ 
  type = "text",
  placeholder,
  className = ""
}: {
  type?: string;
  placeholder?: string;
  className?: string;
}) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      className={`w-full px-4 py-2 bg-input border-2 border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring text-foreground ${className}`}
    />
  )
}
```

### Example 4: Demo Page

```typescript
// app/page.tsx
import { Card } from "@/components/card"
import { Button } from "@/components/button"
import { Input } from "@/components/input"

export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">Universal Styling System</h1>
          <p className="text-muted-foreground text-lg">
            Choose your theme from the bottom-right corner
          </p>
        </div>

        <Card>
          <h2 className="text-2xl font-semibold mb-4">Welcome</h2>
          <p className="text-muted-foreground mb-4">
            This is a demo of the universal styling system with 10 modern themes.
          </p>
          <div className="flex gap-4">
            <Button variant="primary">Primary Action</Button>
            <Button variant="secondary">Secondary</Button>
            <Button variant="accent">Accent</Button>
          </div>
        </Card>

        <Card>
          <h3 className="text-xl font-semibold mb-4">Contact Form</h3>
          <div className="space-y-4">
            <Input placeholder="Your name" />
            <Input type="email" placeholder="your@email.com" />
            <textarea 
              placeholder="Your message"
              className="w-full px-4 py-2 bg-input border-2 border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring text-foreground min-h-[100px]"
            />
            <Button variant="primary" className="w-full">Send Message</Button>
          </div>
        </Card>
      </div>
    </main>
  )
}
```

---

## Usage Tips

1. **Theme Selection**: Users can switch themes using the floating theme switcher in the bottom-right corner
2. **Persistence**: Themes are automatically saved to localStorage by next-themes
3. **Customization**: Modify CSS variables in globals.css to customize any theme
4. **Accessibility**: All themes maintain WCAG AA contrast ratios (except where noted)
5. **Performance**: CSS variables enable instant theme switching without page reload

---

## Best Practices

1. **Test Theme Switching**: Ensure all components work across all 10 themes
2. **Maintain Consistency**: Use CSS variables throughout your components
3. **Accessibility First**: Test color contrast in each theme
4. **Mobile Responsive**: Theme switcher adapts to mobile viewports
5. **SSR Support**: Use `suppressHydrationWarning` to prevent hydration mismatches

---

## Additional Resources

- **Official Docs**: https://nextjs.org/docs/app/building-your-application/styling
- **Tailwind CSS**: https://tailwindcss.com/docs
- **next-themes**: https://github.com/pacocoursey/next-themes
- **shadcn/ui**: https://ui.shadcn.com/themes
- **Color Palette Tool**: https://colorhunt.co/
- **Design Tokens**: https://www.contentful.com/blog/design-token-system/

---

## License

This styling system is open-source and free to use in your projects.

**Created with research from**: Tailwind CSS docs, shadcn/ui, Material Design 3, modern design trends (2025), and Next.js best practices.

---

**Version**: 1.0.0  
**Last Updated**: October 2025  
**Compatible with**: Next.js 15+, Tailwind CSS 4+, React 19+
